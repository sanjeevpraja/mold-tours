<?php
// render.php
// Block rendering function
function callback_block_tour_gallery( $attributes, $content, $block ) {
 $post_id = get_the_ID();
            $gallery_ids = get_post_meta( $post_id, '_tour_gallery', true );

            if ( ! $gallery_ids ) {
                return '<div class="tour-gallery-placeholder">No tour gallery found.</div>';
            }

            $ids = array_filter( array_map( 'absint', explode( ',', $gallery_ids ) ) );
            if ( empty( $ids ) ) return '';

            $html = '<div class="tour-gallery">';
            foreach ( $ids as $id ) {
                $src = wp_get_attachment_image_src( $id, 'medium' );
                if ( $src ) {
                    $html .= '<figure><img src="' . esc_url( $src[0] ) . '" alt="" /></figure>';
                }
            }
            $html .= '</div>';

            return $html;
        }